﻿using MachineTask.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MachineTask.Repository
{
  public   interface IContactRepository: IDisposable
    {
        List<Contact> GetContacts();
        void InsertContact(Contact contact);
        void Save();

    }
}
