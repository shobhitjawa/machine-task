﻿using MachineTask.Models;
using MachineTask.Repository;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace MachineTask.Controllers
{
    public class ContactController : Controller
    {
        private IContactRepository _contactRepository;

        public ContactController(IContactRepository contactRepository)
        {

            _contactRepository = contactRepository;
        }
        public IActionResult Index()
        {
            var contacts = _contactRepository.GetContacts();
            return View(contacts);
        }

        public ActionResult Create()
        {
            return View(new Contact());
        }
        [HttpPost]
        public ActionResult Create(Contact contact)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    _contactRepository.InsertContact(contact);
                    _contactRepository.Save();
                    return RedirectToAction("Index");
                }
            }
            catch (DataException)
            {
                ModelState.AddModelError("", "Unable to save changes. " +
                  "Try again, and if the problem persists see your system administrator.");
            } 
            return View(contact);
        }
    }
}
