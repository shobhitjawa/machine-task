﻿using MachineTask.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MachineTask.Models
{
    public class ContactRepository: IContactRepository
    {
        private ContactContext _context;
        public ContactRepository(ContactContext contactContext)
        {
            this._context = contactContext;
        }
        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    _context.Dispose();
                }
            }
            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        public List<Contact> GetContacts()
        {
            return _context.Contacts.ToList();
        }

        public void InsertContact(Contact contact)
        {
            _context.Contacts.Add(contact);
        } 
        public void Save()
        {
            _context.SaveChanges();
        }

    }
}
